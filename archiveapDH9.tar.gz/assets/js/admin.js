// Admin v2.0 — 3 fields + optional pair import — local-only libs
(() => {
  const $ = (s)=>document.querySelector(s);
  const byName = (n)=>document.querySelector(`input[name="${n}"]:checked`);
  const hasEthers = !!window.ethers;
  const strictAddr = (x)=>{ if(!x||typeof x!=='string') return null; x=x.trim(); try{ return ethers.getAddress(x); }catch{ return null; } };

  const ERC20_META = [
    "function symbol() view returns (string)",
    "function decimals() view returns (uint8)"
  ];
  const PAIR_ABI = [
    "function token0() view returns (address)",
    "function token1() view returns (address)"
  ];

  let cfg=null, provider=null, signer=null, account=null, readProvider=null;

  function chainIdUI(){ return Number(byName('chain').value); }
  function status(msg, kind='info'){ const el=$('#status'); el.textContent=msg||''; el.style.color = kind==='err' ? 'var(--err)' : (kind==='warn' ? 'var(--warn)' : 'var(--muted)'); }

  async function pickReadProvider(chainId){
    const urls = chainId===97
      ? ["https://bsc-testnet.publicnode.com","https://rpc.ankr.com/bsc_testnet","https://data-seed-prebsc-1-s1.binance.org:8545"]
      : ["https://bsc-dataseed.binance.org","https://bsc.publicnode.com","https://rpc.ankr.com/bsc"];
    for (const url of urls){
      try{ const p=new ethers.JsonRpcProvider(url, chainId); await p.getBlockNumber(); return p; }catch(e){}
    }
    return provider;
  }

  async function connect(){
    if(!hasEthers){ status('لم تُحمّل ethers. ضع الملف داخل libs/.', 'warn'); return; }
    if(!window.ethereum){ status('لا توجد محفظة متاحة (MetaMask).', 'warn'); return; }
    provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    signer = await provider.getSigner();
    account= await signer.getAddress();
    const net = await provider.getNetwork();
    readProvider = await pickReadProvider(Number(net.chainId));
    $('#connectBtn').textContent = `متصل (${Number(net.chainId)})`;
    $('#connectBtn').disabled = true;
  }

  function mergeRouters(x){
    const def = {
      "56": {router:"0x10ED43C718714eb63d5aA57B78B54704E256024E", factory:"0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73"},
      "97": {router:"0xD99D1c33F9fC3444f8101754aBC46c52416550D1", factory:"0x6725F303b657a9451d8BA641348b6761A6CC7a17"}
    };
    const out = Object.assign({}, def, x||{});
    for (const k of Object.keys(def)){
      out[k] = Object.assign({}, def[k], out[k]||{});
      if(!out[k].router)  out[k].router  = def[k].router;
      if(!out[k].factory) out[k].factory = def[k].factory;
    }
    return out;
  }

  async function loadCfg(){
    status('تحميل الإعدادات...');
    const r = await fetch('config/get-config.php');
    const j = await r.json().catch(()=>({ok:false,error:'استجابة غير صالحة'}));
    if(!j.ok){ status('خطأ: '+(j.error||''), 'err'); return; }
    cfg = j.config || {};
    cfg.routers = mergeRouters(cfg.routers);

    // advanced
    $('#r56').value = cfg.routers['56'].router;
    $('#f56').value = cfg.routers['56'].factory;
    $('#r97').value = cfg.routers['97'].router;
    $('#f97').value = cfg.routers['97'].factory;

    // slippage
    $('#slip').value = (cfg.defaultSlippagePercent ?? 1.0);

    // tokens of selected chain
    onChainChange();
    status('تم التحميل.');
  }

  async function readTokenMeta(addr){
    if(!hasEthers || !readProvider) return {symbol:'',decimals:18};
    try {
      const c = new ethers.Contract(addr, ERC20_META, readProvider);
      const [sym, dec] = await Promise.all([c.symbol().catch(()=>''), c.decimals().catch(()=>18)]);
      return {symbol:String(sym||''), decimals:Number(dec||18)};
    }catch{ return {symbol:'',decimals:18}; }
  }

  async function importFromPair(){
    const pair = strictAddr($('#pairAddr').value);
    if(!pair){ status('عنوان الحوض غير صالح.', 'warn'); return; }
    if(!hasEthers){ status('الميزة تتطلب ethers.', 'warn'); return; }
    if(!readProvider){ status('اضغط "اتصال المحفظة" أولًا أو أدخل يدويًا.', 'warn'); return; }

    try{
      status('قراءة token0/token1 من الحوض...');
      const pc = new ethers.Contract(pair, PAIR_ABI, readProvider);
      const [t0, t1] = await Promise.all([pc.token0(), pc.token1()]);
      $('#tokenA').value = t0; $('#tokenB').value = t1;
      const [m0, m1] = await Promise.all([readTokenMeta(t0), readTokenMeta(t1)]);
      $('#metaA').textContent = `symbol: ${m0.symbol||'—'} | decimals: ${m0.decimals??'—'}`;
      $('#metaB').textContent = `symbol: ${m1.symbol||'—'} | decimals: ${m1.decimals??'—'}`;
      status('تم الاستيراد.');
    }catch(e){ console.error(e); status('تعذّر القراءة من الحوض. تأكد من العنوان والشبكة.', 'err'); }
  }

  async function saveCfg(){
    if(!cfg){ status('لم تُحمّل الإعدادات بعد.', 'warn'); return; }
    const cid = Number(document.querySelector('input[name="chain"]:checked').value);
    const A = strictAddr($('#tokenA').value);
    const B = strictAddr($('#tokenB').value);
    if(!A || !B){ status('أدخل عناوين 0x صالحة لكل من Token A و Token B.', 'warn'); return; }

    const [mA, mB] = await Promise.all([readTokenMeta(A), readTokenMeta(B)]);
    const tokensObj = (cfg.tokens && typeof cfg.tokens==='object') ? cfg.tokens : {};
    tokensObj[String(cid)] = [
      { symbol: mA.symbol || 'TOKENA', address: A, decimals: mA.decimals || 18 },
      { symbol: mB.symbol || 'TOKENB', address: B, decimals: mB.decimals || 18 },
    ];

    const slip = $('#slip').value.trim();
    const slipNum = (slip===''? (cfg.defaultSlippagePercent??1.0) : Number(slip));
    cfg.defaultSlippagePercent = isFinite(slipNum) ? slipNum : (cfg.defaultSlippagePercent??1.0);

    cfg.routers = mergeRouters({
      "56": {router: $('#r56').value.trim(), factory: $('#f56').value.trim()},
      "97": {router: $('#r97').value.trim(), factory: $('#f97').value.trim()}
    });

    const payload = { routers: cfg.routers, defaultSlippagePercent: cfg.defaultSlippagePercent, tokens: tokensObj };

    status('جارِ الحفظ...');
    const token = $('#adminToken').value || '';
    const r = await fetch('config/save-config.php', {
      method:'POST', headers:{'Content-Type':'application/json', 'X-ADMIN-TOKEN': token}, body: JSON.stringify(payload)
    });
    const j = await r.json().catch(()=>({ok:false,error:'استجابة غير صالحة'}));
    if(j.ok){ status('تم الحفظ.'); } else { status('فشل الحفظ: ' + (j.error||''), 'err'); }
  }

  function onChainChange(){
    const cid = Number(document.querySelector('input[name="chain"]:checked').value);
    const list = (cfg?.tokens?.[String(cid)] || []);
    $('#tokenA').value = list[0]?.address || '';
    $('#tokenB').value = list[1]?.address || '';
    $('#metaA').textContent = `symbol: ${list[0]?.symbol||'—'} | decimals: ${list[0]?.decimals??'—'}`;
    $('#metaB').textContent = `symbol: ${list[1]?.symbol||'—'} | decimals: ${list[1]?.decimals??'—'}`;
    $('#netHint').textContent = '';
  }

  $('#connectBtn').addEventListener('click', connect);
  $('#toggleToken').addEventListener('click', ()=>{ const i=$('#adminToken'); i.type=(i.type==='password'?'text':'password'); });
  $('#importPairBtn').addEventListener('click', importFromPair);
  $('#saveBtn').addEventListener('click', saveCfg);
  $('#loadBtn').addEventListener('click', loadCfg);
  document.querySelectorAll('input[name="chain"]').forEach(r => r.addEventListener('change', onChainChange));

  loadCfg();
})();
