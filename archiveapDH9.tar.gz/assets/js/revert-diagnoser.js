
window.RevertDoctor = (function(){
  function extractError(e){
    try{
      if (e?.reason) return e.reason;
      if (e?.shortMessage) return e.shortMessage;
      if (e?.info?.error?.message) return e.info.error.message;
      if (e?.cause?.message) return e.cause.message;
      return e?.message ? String(e.message) : 'Unknown error';
    }catch{ return 'Unknown error'; }
  }
  async function diagnoseSwap({ router, path, amountIn, amountOutMin, to, deadline, useSupporting=true }){
    try{
      await router.estimateGas.swapExactTokensForTokensSupportingFeeOnTransferTokens(amountIn, amountOutMin, path, to, deadline);
      return { ok:true };
    }catch(e1){
      try{
        await router.estimateGas.swapExactTokensForTokens(amountIn, amountOutMin, path, to, deadline);
        return { ok:true, hint:'استخدم الدالة العادية بدل Supporting' };
      }catch(e2){
        return { ok:false, reason: extractError(e2) };
      }
    }
  }
  return { diagnoseSwap, extractError };
})();