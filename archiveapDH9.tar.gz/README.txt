
Mini Swap — v3.3rc (Clean-room, CSP-safe)

- BSC + Pancake V2 فقط
- سكربتات محلية 100% (لا CDN): ./libs/ethers.umd.min.js ثم ./assets/js/revert-diagnoser.js ثم ./assets/js/app.js?v=3.3rc
- يعتمد لوحة الأدمن عبر window.AdminSwapConfig أو عبر meta tags (fallback: config/* فقط)
- Multi-hop داخلي (Direct/WBNB/USDT/USDC)
- RPC Failover أثناء الجلسة
- FDV/MCAP، تأثير السعر، الحد الأدنى المستلم، تنبيه تغير السعر، تشخيص قبل الإرسال، إصلاح -32603
- بدون أي تغيير على CSS

مهم:
- ضع ملف ethers.umd.min.js داخل ./libs/ (مرفق نسخة محلية).
- لو موقعك ضمن مجلد (مثلاً /swap-mini/)، حافظ على المسارات RELATIVE: استخدم "./assets/..." و "./libs/..." بدل "/assets/...".
- للتحكم من لوحة الأدمن: استعمل admin-config.example.html (أو meta tags).
