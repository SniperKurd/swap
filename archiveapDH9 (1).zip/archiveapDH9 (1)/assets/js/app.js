
/* Diamond Swap Mini v3.3r — Final
 * - BSC/Pancake V2
 * - Auto RPC pick (fastest) + session failover on network errors
 * - Router/Factory verify (admin-trusting, lenient on testnet)
 * - Multi-hop routing (direct, via WBNB/USDT/USDC) internal only
 * - Fee-on-transfer display adjust via config: feeBpsIn / feeBpsOut
 * - Price, Exec, Impact, MinReceived, FDV/MCAP (no reserves shown)
 * - Slippage guard + High-impact confirm
 * - Revert Diagnoser preflight
 * - Legacy gas overrides (-32603 fix)
 * - CSP-safe, no CSS edits
 */
(() => {
  'use strict';
  // ===== Debug Toggle =====
  // ===== Debug Toggle (أعلى الملف بعد 'use strict') =====
let DEBUG = false;
try {
  const q = new URLSearchParams(location.search);
  if (q.has('debug')) DEBUG = (q.get('debug')==='1' || q.get('debug')==='true');
} catch {}
if (typeof window !== 'undefined') {
  try { if (sessionStorage.getItem('swapMini.debug')==='1') DEBUG = true; } catch {}
  try { if (localStorage.getItem('swapMini.debug')==='1') DEBUG = true; } catch {}
  if (window.AdminSwapConfig && typeof window.AdminSwapConfig.debug === 'boolean') DEBUG = !!window.AdminSwapConfig.debug;
  if (typeof window.SWAP_DEBUG === 'boolean') DEBUG = !!window.SWAP_DEBUG;
}
function setDebug(on){ DEBUG = !!on; try{ sessionStorage.setItem('swapMini.debug', on?'1':'0'); }catch{} }

// بانيل صغيرة للديبغ (بدون لمس CSS)
let dbgEl=null;
function ensureDbg(){
  if (dbgEl||!DEBUG) return dbgEl;
  try{
    dbgEl=document.createElement('pre');
    dbgEl.id='swapMiniDebug'; dbgEl.dir='ltr';
    dbgEl.style.cssText='position:fixed;bottom:8px;left:8px;max-width:40vw;max-height:35vh;overflow:auto;background:rgba(0,0,0,.6);color:#0ff;padding:10px 12px;border-radius:10px;font:12px/1.3 monospace;z-index:99999;white-space:pre-wrap;opacity:.9;';
    document.body.appendChild(dbgEl);
  }catch{}
  return dbgEl;
}

// ✅ إصلاح السطر 32 (كان فيه كسر سطر داخل النص)
function dlog(tag, obj){
  if (!DEBUG) return;
  try {
    const ts = new Date().toISOString().split('T')[1].replace('Z','');
    console.groupCollapsed(`[DBG ${ts}] ${tag}`);
    if (obj !== undefined) console.log(obj);
    console.groupEnd();
    const el = ensureDbg();
    if (el){
      el.textContent += `\n[${ts}] ${tag}${obj?': '+(typeof obj==='string'?obj:JSON.stringify(obj,null,2)):''}`;
      const L = el.textContent.split('\n');
      if (L.length > 400) el.textContent = L.slice(-400).join('\n');
    }
  } catch {}
}
window.SwapMiniDebug = { set: setDebug, on: ()=>setDebug(true), off: ()=>setDebug(false) };

  const qs = (s)=>document.querySelector(s);
  const pick = (...sels)=> sels.map(qs).find(Boolean);
  const els = {
    connectBtn: pick('#connectBtn','#btn-connect','#connect','button[data-role="connect"]'),
    approveBtn: pick('#approveBtn','#btn-approve','button[data-role="approve"]'),
    swapBtn:    pick('#swapBtn','#btn-swap','button[data-role="swap"]'),
    reverseBtn: pick('#reverseBtn','#btn-reverse','button[data-role="reverse"]'),
    fromAmount: pick('#fromAmount','#amountIn','input[name="from"]'),
    toAmount:   pick('#toAmount','input[name="to"]'),
    slippage:   pick('#slippage','input[name="slippage"]'),
    status:     pick('#status','.status'),
    alert:      pick('#alert','.alert'),
    netName:    pick('#netName','#networkTag','.net-name'),
    pairSel:    pick('#pairSel'),
    pairTitle:  pick('#pairTitle','.pair-title'),
    fromSym:    pick('#fromSym','.from-sym'),
    toSym:      pick('#toSym','.to-sym'),
    livePrice:  pick('#livePrice','.live-price'),
    price:      pick('#price','.exec-price'),
    priceImpact:pick('#priceImpact','.price-impact'),
    minOut:     pick('#minOut','.min-out'),
    invPrice:   pick('#invPrice','.inv-price'),
    fdv:        pick('#fdv','.fdv'),
    mcap:       pick('#mcap','.mcap'),
    liquidity:  pick('#liquidity','.liquidity'),
  };

  const CHAINS={
    56:{name:'BSC Mainnet', wnative:'0xBB4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', USDT:'0x55d398326f99059fF775485246999027B3197955', USDC:'0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d'},
    97:{name:'BSC Testnet', wnative:'0xae13d989dac2f0debff460ac112a837c89baa7cd', USDT:'0x7ef95a0fEE0Dd31b22626fA2c6A3a3bD0d3fBf47', USDC:'0x64544969ed7EBf5f083679233325356EbE738930'}
  };
  const ROUTERS={
    56:[{name:'Pancake V2', router:'0x10ED43C718714eb63d5aA57B78B54704E256024E', factory:'0xCA143Ce32Fe78f1f7019d7d551a6402fC5350c73'}],
    97:[{name:'Pancake V2 (testnet)', router:'0x9Ac64cc6e4415144C455BD8E4837Fea55603e5c3', factory:'0x6725F303b657a9451d8BA641348b6761A6CC7a17'}]
  };
  const RPCS={
    56:['https://bsc-dataseed.binance.org','https://bsc-dataseed1.binance.org','https://bsc-dataseed2.binance.org','https://bsc.publicnode.com','https://bsc.blockpi.network/v1/rpc/public','https://bsc-mainnet.public.blastapi.io'],
    97:['https://data-seed-prebsc-1-s1.binance.org:8545/','https://bsc-testnet.blockpi.network/v1/rpc/public','https://endpoints.omniatech.io/v1/bsc/testnet/public','https://bsc-testnet.public.blastapi.io']
  };
  const ROUTER_ABI=[
    'function factory() view returns (address)',
    'function getAmountsOut(uint amountIn, address[] memory path) view returns (uint[] memory amounts)',
    'function swapExactTokensForTokens(uint amountIn,uint amountOutMin,address[] calldata path,address to,uint deadline) returns (uint[] memory amounts)',
    'function swapExactTokensForTokensSupportingFeeOnTransferTokens(uint amountIn,uint amountOutMin,address[] calldata path,address to,uint deadline)'
  ];
  const FACTORY_ABI=[
    'function getPair(address tokenA, address tokenB) view returns (address)',
    'function allPairsLength() view returns (uint256)'
  ];
  const PAIR_ABI=[
    'function token0() view returns (address)',
    'function token1() view returns (string)',
    'function getReserves() view returns (uint112,uint112,uint32)'
  ].map(x=> x.replace('string','address')); // safety in case ABI typo
  const ERC20_ABI=[
    'function symbol() view returns (string)',
    'function name() view returns (string)',
    'function decimals() view returns (uint8)',
    'function totalSupply() view returns (uint256)',
    'function balanceOf(address) view returns (uint256)',
    'function allowance(address,address) view returns (uint256)',
    'function approve(address,uint256) returns (bool)'
  ];

  let chainId=56, rpc='', routerAddr='', factoryAddr='';
  let ro=null, router=null, factory=null, pair=null, pairAddr='';
  let wallet={ provider:null, signer:null, address:null, net:null };
  let tok={ A:{}, B:{} }, reserves={ a:0n, b:0n };
  let pollT=null, lastPoolPrice=0, priceAlertTO=null;

  // Optional fees for display
  let feeBpsIn = 0;
  let feeBpsOut = 0;
  const applyFeesIn = (amt)=> amt - (amt * BigInt(feeBpsIn)) / 10000n;
  const applyFeesOut = (amt)=> amt - (amt * BigInt(feeBpsOut)) / 10000n;

  let currentPath = [];

  const setAlert=(msg,type='warn')=>{ if(!els.alert) return; if(!msg){ els.alert.hidden=true; els.alert.textContent=''; els.alert.className='alert'; return; } els.alert.hidden=false; els.alert.textContent=msg; els.alert.className='alert '+type; };
  const setStatus=(m)=>{ if(els.status) els.status.textContent=m||''; };

  function showTxNotice(inRaw, outRaw, symA, decA, symB, decB, hash){
    try{
      const inHuman = Number(ethers.formatUnits(inRaw||0n, decA));
      const outHuman = Number(ethers.formatUnits(outRaw||0n, decB));
      const msg = `تمّت العملية: ${fmt(inHuman,6)} ${symA} → ${fmt(outHuman,6)} ${symB}` + (hash? `\nTX: ${hash}` : '');
      setAlert(msg, 'info');
      try{ setTimeout(()=> setAlert(''), 8000); }catch{}
    }catch{}
  }

  const fmt=(n,fd=6)=>{ const x=Number(n); return Number.isFinite(x)? x.toLocaleString(undefined,{maximumFractionDigits:fd}):'—'; };
  const addrOk=(v)=> /^0x[a-fA-F0-9]{40}$/.test((v||'').trim());
  const parseAmount=(txt,dec=18)=>{ const v=(txt||'').replace(/[^\d.]/g,'').trim(); if(!v) return 0n; try{return ethers.parseUnits(v,dec);}catch{return 0n;} };
  const fetchJSON=async(url)=>{ const r=await fetch(url,{cache:'no-store'}); if(!r.ok) throw new Error('HTTP '+r.status); return await r.json(); };

  // ===== Admin-driven settings (primary) =====
  async function tryJSON(url){
    try{
      const r = await fetch(url, {cache:'no-store'});
      if(!r.ok) return null;
      return await r.json();
    }catch{ return null; }
  }
  function readMeta(){
    const pick = (n)=> (document.querySelector(`meta[name="${n}"]`)||{}).content || null;
    const m = {};
    const keys = ['chainId','router','factory','pair','feeBpsIn','feeBpsOut','slippageDefault','tradingEnabled'];
    keys.forEach(k=>{ const v = pick('swap:'+k); if(v!=null && v!=='') m[k]=v; });
    return m;
  }
  function readWindowAdmin(){
    // Allow admin to inject window.AdminSwapConfig or window.ADMIN_SWAP
    const w = window;
    const c = w.AdminSwapConfig || w.ADMIN_SWAP || w.__ADMIN_SWAP__ || null;
    if(!c) return {};
    try{
      // clone shallow
      const j = JSON.parse(JSON.stringify(c));
      return j;
    }catch{ return {}; }
  }
  async function loadAdminSettings(){
    // Priority: window.* -> /admin endpoints -> /config endpoints
    let j = {};
    // window globals
    Object.assign(j, readWindowAdmin());

    // admin endpoints (common patterns)
    const adminUrls = [];
    for(const u of adminUrls){
      const x = await tryJSON(u);
      if (x && typeof x === 'object') Object.assign(j, x);
    }
    // meta tags override
    Object.assign(j, readMeta());

    // config fallback
    const confUrls = ['config/get-config.php', 'config/config.json'];
    for(const u of confUrls){
      const x = await tryJSON(u);
      if (x && typeof x === 'object') Object.assign(j, x);
    }

    // Normalize fields possibly nested
    function dig(obj, keys){
      let v=obj;
      for(const k of keys){
        if(v && typeof v==='object' && (k in v)) v = v[k]; else return null;
      }
      return v;
    }
    const aliases = [
      ['router', ['router','pancakeRouter','routerAddress']],
      ['factory',['factory','pancakeFactory','factoryAddress']],
      ['pair',   ['pair','pairAddress','lp','pool','poolAddress']],
      ['feeBpsIn',['feeBpsIn','taxInBps','buyFeeBps']],
      ['feeBpsOut',['feeBpsOut','taxOutBps','sellFeeBps']],
      ['slippageDefault',['slippageDefault','defaultSlippage','slippage']],
      ['tradingEnabled',['tradingEnabled','trading','swapEnabled']],
      ['chainId',['chainId','chainID','chain']],
    ];
    const out = {};
    for(const [canon, al] of aliases){
      for(const k of al){
        if(j && typeof j==='object' && k in j && j[k]!=null){
          out[canon] = j[k];
          break;
        }
      }
      // Also check nested admin.settings.* or data.*
      if(!(canon in out)){
        const nested = dig(j, ['admin','settings', al[0]]) || dig(j, ['data', al[0]]) || null;
        if(nested!=null) out[canon] = nested;
      }
    }

    // pairs array support
    if(!out.pair){
      try{
        const arr = j.pairs || dig(j,['admin','settings','pairs']) || null;
        if (Array.isArray(arr) && arr.length && arr[0] && arr[0].pair) out.pair = arr[0].pair;
      }catch{}
    }

    // casting
    if(out.chainId!=null) out.chainId = Number(out.chainId);
    if(out.feeBpsIn!=null) out.feeBpsIn = Number(out.feeBpsIn);
    if(out.feeBpsOut!=null) out.feeBpsOut = Number(out.feeBpsOut);
    if(out.slippageDefault!=null) out.slippageDefault = Number(out.slippageDefault);
    if(out.tradingEnabled!=null) out.tradingEnabled = (String(out.tradingEnabled).toLowerCase()!=='false');

    return out;
  }

  function listenAdminUpdates(onChange){
    try{
      window.addEventListener('storage', (e)=>{
        if(e && e.key==='admin.swap.config'){ try{ onChange && onChange(JSON.parse(e.newValue)); }catch{} }
      });
    }catch{}
  }


  async function testRPC(url, expected){
    const t0=performance.now();
    try{
      const p=new ethers.JsonRpcProvider(url);
      const ch=Number(await p.send('net_version',[]));
      if(expected && ch!==expected) throw 0;
      await p.getBlockNumber();
      return {ok:true,latency:performance.now()-t0,provider:p};
    }catch{ return {ok:false}; }
  }
  async function pickRPC(cands, expected){
    const key=`swapMini.rpc.${expected}`;
    const cached = sessionStorage.getItem(key) || localStorage.getItem(key);
    if(cached){ const r=await testRPC(cached, expected); if(r.ok) return {url:cached,provider:r.provider,latency:r.latency}; }
    const tests=await Promise.all(cands.map(u=>testRPC(u,expected)));
    const oks=tests.map((r,i)=>({...r,url:cands[i]})).filter(r=>r.ok).sort((a,b)=>a.latency-b.latency);
    if(!oks.length) throw new Error('لا يوجد RPC يعمل الآن');
    sessionStorage.setItem(key, oks[0].url);
    return {url:oks[0].url,provider:oks[0].provider,latency:oks[0].latency};
  }
  async function safeCall(fn, onRepick=null){
    try{ return await fn(); }
    catch(e){
      const msg=(e?.message||'').toLowerCase();
      if (msg.includes('network') || msg.includes('timeout') || msg.includes('failed')){
        const picked = await pickRPC(RPCS[chainId]||[], chainId);
        dlog('RPC picked', {url:picked.url, latency: Math.round(picked.latency), chainId});
      rpc = picked.url; ro = picked.provider;
        if (addrOk(routerAddr)) router = new ethers.Contract(routerAddr, ROUTER_ABI, ro);
        if (addrOk(factoryAddr)) factory = new ethers.Contract(factoryAddr, FACTORY_ABI, ro);
        if (addrOk(pairAddr)) pair = new ethers.Contract(pairAddr, PAIR_ABI_SIMPLE, ro);
        onRepick && onRepick();
        return await fn();
      }
      throw e;
    }
  }

  function calcOutK(amountIn,reserveIn,reserveOut){
    if (amountIn<=0n || reserveIn<=0n || reserveOut<=0n) return 0n;
    const amountInWithFee = amountIn * 9975n / 10000n;
    return (amountInWithFee * reserveOut) / (reserveIn + amountInWithFee);
  }
  async function getPairAddr(a,b){ try{ const p=await factory.getPair(a,b); return (addrOk(p) && p!='0x0000000000000000000000000000000000000000')? p:null; }catch{ return null; } }
  async function getReservesFor(a,b){
    const p=await getPairAddr(a,b); if(!p) return null;
    const pr=new ethers.Contract(p, PAIR_ABI, ro);
    const [r0,r1]=await pr.getReserves(); const t0=await pr.token0(); const Ais0=(t0.toLowerCase()===a.toLowerCase());
    const inAddr=Ais0?a:b, outAddr=Ais0?b:a;
    const inC=new ethers.Contract(inAddr, ERC20_ABI, ro), outC=new ethers.Contract(outAddr, ERC20_ABI, ro);
    const [dIn,dOut]=await Promise.all([inC.decimals().catch(()=>18), outC.decimals().catch(()=>18)]);
    const reserveIn=Ais0? BigInt(r0):BigInt(r1), reserveOut=Ais0? BigInt(r1):BigInt(r0);
    return { reserveIn, reserveOut, decIn:Number(dIn), decOut:Number(dOut) };
  }
  async function quotePath(amountInRaw, path){
    if(!path || path.length<2) return 0n;
    let amt = amountInRaw;
    for(let i=0;i<path.length-1;i++){
      const a=path[i], b=path[i+1];
      const res=await getReservesFor(a,b);
      if(!res) return 0n;
      amt = calcOutK(amt, res.reserveIn, res.reserveOut);
      if (i===0) amt = applyFeesIn(amt);
      if (i===path.length-2) amt = applyFeesOut(amt);
    }
    return amt;
  }
  async function bestPathFor(amountInRaw, fromAddr, toAddr){
    const net=CHAINS[chainId];
    const cands = [
      [fromAddr, toAddr],
      [fromAddr, net.wnative, toAddr],
      net.USDT ? [fromAddr, net.USDT, toAddr] : null,
      net.USDC ? [fromAddr, net.USDC, toAddr] : null,
      (net.USDT && net.wnative) ? [fromAddr, net.wnative, net.USDT, toAddr] : null
    ].filter(Boolean);
    let best={ path:null, out:0n };
    for(const p of cands){
      try{ const out=await quotePath(amountInRaw, p); if(out>best.out) best={path:p, out}; }catch{}
    }
    return best;
  }

  const PAIR_ABI_SIMPLE=['function token0() view returns (address)','function token1() view returns (address)','function getReserves() view returns (uint112,uint112,uint32)'];

  async function verifyRouterFactory(pvd){
    const list=[];
    if(addrOk(routerAddr)) list.push({name:'Admin',router:routerAddr,factory:factoryAddr||''});
    (ROUTERS[chainId]||[]).forEach(x=>{ if(!list.find(y=> y.router.toLowerCase()===x.router.toLowerCase())) list.push(x); });
    const isTestnet=(Number(chainId)!==56);
    let lastErr=null;
    for(const it of list){
      try{
        const rt=new ethers.Contract(it.router, ROUTER_ABI, pvd);
        const fFrom=await rt.factory().catch(()=> '0x0000000000000000000000000000000000000000');
        const fact= addrOk(it.factory) ? it.factory : (addrOk(fFrom)? fFrom : null);
        if(!fact){ lastErr='router.factory() غير متاح'; continue; }
        const fac=new ethers.Contract(fact, FACTORY_ABI, pvd);
        try{ await fac.allPairsLength(); }catch{}
        let ok=true;
        if(!isTestnet){
          ok=false;
          const net=CHAINS[chainId];
          for(const st of [net.USDT, net.USDC]){
            try{ const p=await fac.getPair(net.wnative, st); if(addrOk(p) && p!='0x0000000000000000000000000000000000000000'){ ok=true; break; } }catch{}
          }
        }
        if(ok){ routerAddr=it.router; factoryAddr=fact; router=rt; factory=fac; setStatus(`Router OK: ${routerAddr.slice(0,6)}… | Factory: ${factoryAddr.slice(0,6)}…`); return true; }
        if(it.name==='Admin'){ routerAddr=it.router; factoryAddr=fact; router=rt; factory=fac; setStatus(`Router/Factory اعتمدت من إعدادات الأدمن.`); return true; }
        lastErr='لم نجد أزواج مرجعية، لكن factory متاح';
      }catch(e){ lastErr=e?.message||String(e); }
    }
    throw new Error(lastErr||'تعذّر تحديد Router/Factory صالحين');
  }

  async function attachPair(pAddr,pvd){
    pairAddr = pAddr;
    dlog('attachPair', {pair:pAddr});
      pair=new ethers.Contract(pAddr, PAIR_ABI_SIMPLE, pvd);
    const [a0,a1]=await Promise.all([pair.token0(), pair.token1()]);
    const A=new ethers.Contract(a0, ERC20_ABI, pvd), B=new ethers.Contract(a1, ERC20_ABI, pvd);
    const [symA,symB,decA,decB,nameA,nameB]=await Promise.all([A.symbol().catch(()=> 'T0'),B.symbol().catch(()=> 'T1'),A.decimals().catch(()=>18),B.decimals().catch(()=>18),A.name().catch(()=> 'Token0'),B.name().catch(()=> 'Token1')]);
    tok.A={addr:a0,sym:symA,dec:Number(decA),name:nameA,c:A};
    tok.B={addr:a1,sym:symB,dec:Number(decB),name:nameB,c:B};
    els.fromSym && (els.fromSym.textContent=tok.A.sym);
    els.toSym && (els.toSym.textContent=tok.B.sym);
    els.pairTitle && (els.pairTitle.textContent=`${tok.A.sym}/${tok.B.sym}`);
    els.pairSel && (els.pairSel.innerHTML=`<option>${tok.A.sym}/${tok.B.sym}</option>`, els.pairSel.disabled=true);
    await updateReserves(true);
  }

  async function updateReserves(first=false){
    if(!pair) return;
    const [r0,r1]=await safeCall(()=> pair.getReserves());
    dlog('reserves', {a:r0?.toString?.(), b:r1?.toString?.()});
      reserves={a:BigInt(r0), b:BigInt(r1)};
    const poolPrice = reserves.a>0n ? Number(ethers.formatUnits(reserves.b,tok.B.dec)) / Number(ethers.formatUnits(reserves.a,tok.A.dec)) : 0;
    dlog('pool price', {poolPrice});
      els.livePrice && (els.livePrice.textContent = `${fmt(poolPrice,8)} ${tok.B.sym}/${tok.A.sym}`);
    els.invPrice && (els.invPrice.textContent = poolPrice>0? `1 ${tok.B.sym} ≈ ${fmt(1/poolPrice,8)} ${tok.A.sym}` : '—');
    if(lastPoolPrice>0 && poolPrice>0){
      const change = Math.abs((poolPrice - lastPoolPrice)/lastPoolPrice) * 100;
      if(change >= 0.5){ setAlert(`إشعار: السعر تغيّر ${fmt(change,2)}% منذ آخر تحديث.`, 'info'); clearTimeout(priceAlertTO); priceAlertTO=setTimeout(()=> setAlert(''), 3500); }
    }
    lastPoolPrice = poolPrice;
    try{ await updateFDV(poolPrice); }catch{}
    if(first && (els.fromAmount?.value||'').trim()!=='') Promise.resolve(recalcQuote());
  }

  async function updateFDV(priceAB){
    const net=CHAINS[chainId];
    let priceBUSD=1;
    if([net.USDT.toLowerCase(), net.USDC.toLowerCase()].includes(tok.B.addr.toLowerCase())) priceBUSD=1;
    else if(tok.B.addr.toLowerCase()===net.wnative.toLowerCase()){
      const p=await factory.getPair(net.wnative, net.USDT);
      if(addrOk(p) && p!='0x0000000000000000000000000000000000000000'){
        const pr=new ethers.Contract(p, PAIR_ABI_SIMPLE, ro);
        const [r0,r1]=await pr.getReserves(); const t0=await pr.token0(); const wIs0=(t0.toLowerCase()===net.wnative.toLowerCase());
        const resWN = wIs0 ? Number(ethers.formatUnits(r0,18)) : Number(ethers.formatUnits(r1,18));
        const resUSDT = wIs0 ? Number(ethers.formatUnits(r1,18)) : Number(ethers.formatUnits(r0,18));
        priceBUSD = resUSDT / Math.max(1e-18, resWN);
      }
    } else {
      const p=await factory.getPair(tok.B.addr, net.USDT);
      if(addrOk(p) && p!='0x0000000000000000000000000000000000000000'){
        const pr=new ethers.Contract(p, PAIR_ABI_SIMPLE, ro);
        const [r0,r1]=await pr.getReserves(); const t0=await pr.token0(); const bIs0=(t0.toLowerCase()===tok.B.addr.toLowerCase());
        const resB = bIs0 ? Number(ethers.formatUnits(r0, tok.B.dec)) : Number(ethers.formatUnits(r1, tok.B.dec));
        const resUSDT = bIs0 ? Number(ethers.formatUnits(r1, 18)) : Number(ethers.formatUnits(r0, 18));
        priceBUSD = resUSDT / Math.max(1e-18, resB);
      }
    }
    const priceAUSD = priceAB * priceBUSD;
    let total=0n; try{ total = await tok.A.c.totalSupply(); }catch{}
    let burned=0n; try{ const dead=await tok.A.c.balanceOf('0x000000000000000000000000000000000000dEaD'); const zero=await tok.A.c.balanceOf('0x0000000000000000000000000000000000000000'); burned=(dead||0n)+(zero||0n); }catch{}
    const circ = total>burned ? (total-burned) : total;
    const fdvUSD = Number(ethers.formatUnits(total, tok.A.dec))*priceAUSD;
    const mcapUSD = Number(ethers.formatUnits(circ, tok.A.dec))*priceAUSD;
    els.fdv && (els.fdv.textContent = `FDV ~ ${fmt(fdvUSD,2)} USD`);
    els.mcap && (els.mcap.textContent = `MCAP ~ ${fmt(mcapUSD,2)} USD`);
  }

  async function recalcQuote(){
    try{
      const inRaw = parseAmount(els.fromAmount?.value, tok.A.dec);
      if (inRaw<=0n){ els.toAmount && (els.toAmount.value=''); setAlert(''); return; }
      dlog('best path', {inRaw: inRaw?.toString?.(), from: tok.A.addr, to: tok.B.addr});
      const best = await bestPathFor(inRaw, tok.A.addr, tok.B.addr);
      currentPath = best.path || [tok.A.addr, tok.B.addr];
      dlog('path chosen', {path: currentPath});
      const outRaw = best.out;
      els.toAmount && (els.toAmount.value = outRaw>0n ? String(Number(ethers.formatUnits(outRaw, tok.B.dec))) : '');
      const exec = outRaw>0n ? (Number(ethers.formatUnits(outRaw,tok.B.dec)) / Math.max(1e-18, Number(ethers.formatUnits(inRaw||1n, tok.A.dec)))) : 0;
      let pool=0; if(reserves.a>0n){ pool = Number(ethers.formatUnits(reserves.b,tok.B.dec)) / Number(ethers.formatUnits(reserves.a,tok.A.dec)); }
      const impact = pool>0 ? (1 - (exec/ pool)) * 100 : 0;
      dlog('exec price', {exec});
      els.price && (els.price.textContent = `${fmt(exec,8)} ${tok.B.sym}/${tok.A.sym}`);
      dlog('impact %', {impact});
      els.priceImpact && (els.priceImpact.textContent = `تأثير السعر: ${fmt(impact,2)}%`);
      const slip = Math.max(0, Number(els.slippage?.value || '1'));
      const minOut = outRaw - (outRaw * BigInt(Math.round(slip*100))) / 10000n;
      els.minOut && (els.minOut.textContent = `${fmt(Number(ethers.formatUnits(minOut<0n?0n:minOut,tok.B.dec)),6)} ${tok.B.sym}`);
      if (slip < 0.1) setAlert('تنبيه: تحمّل الانزلاق منخفض جدًا وقد تفشل الصفقة.', 'info');
      else if (slip > 5) setAlert('تحذير: تحمّل الانزلاق مرتفع؛ قد تحصل على سعر أسوأ بكثير.', 'warn');
      else setAlert('');
    }catch(e){ setAlert(e?.message||'فشل احتساب التسعير','error'); }
  }

  async function connectWallet(){
    if(!window.ethereum){ setAlert('لا توجد محفظة (MetaMask).','warn'); return; }
    wallet.provider = new ethers.BrowserProvider(window.ethereum);
    await wallet.provider.send('eth_requestAccounts', []);
    wallet.signer = await wallet.provider.getSigner();
    wallet.address = await wallet.signer.getAddress();
    wallet.net = await wallet.provider.getNetwork();
    if(Number(wallet.net.chainId)!==chainId){
      try{ await window.ethereum.request({ method:'wallet_switchEthereumChain', params:[{ chainId:'0x'+chainId.toString(16) }] }); }
      catch(e){ setAlert('تعذّر التبديل للشبكة المطلوبة.','warn'); }
    }
    els.connectBtn && (els.connectBtn.textContent = `متصل (${chainId})`);
    setStatus('');
  }

  async function approveIfNeeded(amountInRaw){
    const c = new ethers.Contract(tok.A.addr, ERC20_ABI, wallet.signer);
    const allowance = await c.allowance(wallet.address, routerAddr);
    if (allowance >= amountInRaw) return true;
    setStatus('إرسال موافقة…');
    const tx = await c.approve(routerAddr, amountInRaw);
    await tx.wait();
    setStatus('تمّت الموافقة.');
    return true;
  }
  window.SwapMini_approveIfNeeded = approveIfNeeded;

  async function legacyOverrides(estFn){
    let gasPrice=null; try{ const fee=await wallet.provider.getFeeData(); gasPrice=fee.gasPrice||null; }catch{}
    if(!gasPrice){ try{ gasPrice = ethers.parseUnits('3','gwei'); }catch{ gasPrice = 3_000_000_000n; } }
    let gasLimit=600000n; try{ const est=await estFn(); gasLimit=(est*125n)/100n; if(gasLimit<180000n) gasLimit=180000n; if(gasLimit>2000000n) gasLimit=2000000n; }catch{}
    return { gasPrice, gasLimit };
  }

  async function doSwap(){
    try{
      if(!wallet.signer){ setAlert('اتصل بالمحفظة أولًا.','warn'); return; }
      const inRaw = parseAmount(els.fromAmount?.value, tok.A.dec);
      if(inRaw<=0n){ setAlert('أدخل قيمة صحيحة.','warn'); return; }
      const slip = Math.max(0, Number(els.slippage?.value || '1'));
      dlog('best path', {inRaw: inRaw?.toString?.(), from: tok.A.addr, to: tok.B.addr});
      const best = await bestPathFor(inRaw, tok.A.addr, tok.B.addr);
      currentPath = best.path || [tok.A.addr, tok.B.addr];
      dlog('path chosen', {path: currentPath});
      const outRaw = best.out;
      const minOut = outRaw - (outRaw * BigInt(Math.round(slip*100))) / 10000n;
      const deadline = Math.floor(Date.now()/1000) + 60*20;

      // Impact confirm
      let pool=0; if(reserves.a>0n){ pool = Number(ethers.formatUnits(reserves.b,tok.B.dec)) / Number(ethers.formatUnits(reserves.a,tok.A.dec)); }
      const exec = outRaw>0n ? (Number(ethers.formatUnits(outRaw,tok.B.dec)) / Math.max(1e-18, Number(ethers.formatUnits(inRaw||1n, tok.A.dec)))) : 0;
      const impact = pool>0 ? (1 - (exec/ pool)) * 100 : 0;
      if (impact >= 10) { setAlert(`تحذير: تأثير السعر ${fmt(impact,2)}% — قد تحصل على سعر أسوأ.`, 'warn');  }

      if (window.RevertDoctor){
        const diag = await RevertDoctor.diagnoseSwap({ router, path:currentPath, amountIn:inRaw, amountOutMin:(minOut<0n?0n:minOut), to:wallet.address, deadline, useSupporting:true });
        if (!diag.ok){ setAlert(diag.reason || diag.hint || 'فشل المحاكاة (require(false))','error'); return; }
      }

      dlog('approveIfNeeded', {inRaw: inRaw?.toString?.()});
      await approveIfNeeded(inRaw);
      const overrides = await safeCall(()=> legacyOverrides(()=> router.estimateGas.swapExactTokensForTokensSupportingFeeOnTransferTokens(inRaw,(minOut<0n?0n:minOut),currentPath,wallet.address,deadline)));
      dlog('sending swap', {minOut: (minOut<0n?0n:minOut)?.toString?.(), deadline});
      setStatus('إرسال المعاملة…');
      try{
        const tx = await safeCall(()=> router.swapExactTokensForTokensSupportingFeeOnTransferTokens(inRaw,(minOut<0n?0n:minOut),currentPath,wallet.address,deadline,overrides));
        dlog('swap success', {hash: tx?.hash});
      await tx.wait(); setStatus('تمت المعاملة ✓'); showTxNotice(inRaw, outRaw, tok.A.sym, tok.A.dec, tok.B.sym, tok.B.dec, tx?.hash);
      }catch(e1){
        const ov2 = await safeCall(()=> legacyOverrides(()=> router.estimateGas.swapExactTokensForTokens(inRaw,(minOut<0n?0n:minOut),currentPath,wallet.address,deadline)));
        try{
          const tx2 = await safeCall(()=> router.swapExactTokensForTokens(inRaw,(minOut<0n?0n:minOut),currentPath,wallet.address,deadline,ov2));
          dlog('swap success (fallback)', {hash: tx2?.hash});
      await tx2.wait(); setStatus('تمت المعاملة ✓'); showTxNotice(inRaw, outRaw, tok.A.sym, tok.A.dec, tok.B.sym, tok.B.dec, tx2?.hash);
        }catch(e2){
          const reason = (window.RevertDoctor && RevertDoctor.extractError) ? RevertDoctor.extractError(e2) : (e2?.message || 'فشل');
          dlog('swap fail', {reason});
      setStatus(''); setAlert('فشل: '+reason, 'error');
        }
      }
    }catch(e){ setStatus(''); setAlert(e?.reason||e?.message||'فشل العملية','error'); }
  }

  function bind(){
    els.fromAmount && els.fromAmount.addEventListener('input', ()=>{ setAlert(''); Promise.resolve(recalcQuote()); });
    els.reverseBtn && els.reverseBtn.addEventListener('click', ()=>{ const t=tok.A; tok.A=tok.B; tok.B=t; const r=reserves; reserves={a:r.b,b:r.a}; els.fromSym && (els.fromSym.textContent=tok.A.sym); els.toSym && (els.toSym.textContent=tok.B.sym); Promise.resolve(recalcQuote()); });
    els.slippage && els.slippage.addEventListener('change', ()=>{ sessionStorage.setItem('swapMini.slippage', String(els.slippage.value||'')); Promise.resolve(recalcQuote()); });
    els.connectBtn && els.connectBtn.addEventListener('click', ()=> connectWallet().catch(e=> setAlert(e?.message||String(e),'error')));
    els.approveBtn && els.approveBtn.addEventListener('click', ()=>{ try{ const inRaw=parseAmount(els.fromAmount?.value,tok.A.dec); if(inRaw<=0n){ setAlert('أدخل قيمة صحيحة.','warn'); return; } approveIfNeeded(inRaw).catch(e=> setAlert(e?.message||String(e),'error')); }catch(e){ setAlert(e?.message||String(e),'error'); } });
    els.swapBtn && els.swapBtn.addEventListener('click', ()=> doSwap());
  }

  async function loadConfig(){
    // Pull admin first
    const admin = await loadAdminSettings();
    let j={}; try{ j=await fetchJSON('config/get-config.php'); }catch(_){ try{ j=await fetchJSON('config/config.json'); }catch(__){} }

    chainId = Number((admin.chainId!=null? admin.chainId : (j.chainId || 56)));
    const net=CHAINS[chainId] || CHAINS[56];

    // prefer admin
    rpc = String(j.rpc || '');
    routerAddr = String((admin.router || j.router || ''));
    factoryAddr = String((admin.factory || j.factory || ''));
    const adminPair = (admin.pair && /^0x[a-fA-F0-9]{40}$/.test(admin.pair)) ? admin.pair : null;

    feeBpsIn = Number((admin.feeBpsIn!=null? admin.feeBpsIn : (j.feeBpsIn || 0)));
    feeBpsOut= Number((admin.feeBpsOut!=null? admin.feeBpsOut : (j.feeBpsOut || 0)));
    const slDef = (admin.slippageDefault!=null? admin.slippageDefault : (j.slippageDefault || null));
    if (slDef!=null && els.slippage) els.slippage.value = String(slDef);

    // trading enable/disable
    const tradingEnabled = (admin.tradingEnabled!=null? admin.tradingEnabled : true);
    if (!tradingEnabled && els.swapBtn){ els.swapBtn.disabled = true; setAlert('التداول متوقف من لوحة الأدمن.', 'warn'); }
    els.netName && (els.netName.textContent = `${net.name} (${chainId})`);

    // RPC pick
    const picked = await pickRPC(rpc ? [rpc, ...(RPCS[chainId]||[])] : (RPCS[chainId]||[]), chainId);
    dlog('RPC picked', {url:picked.url, latency: Math.round(picked.latency), chainId});
      rpc = picked.url; ro = picked.provider; setStatus(`RPC جاهز (${Math.round(picked.latency)}ms)`);

    // Router/Factory verify (prefer admin)
    try{ dlog('verifyRouterFactory:start');
      await verifyRouterFactory(ro); }
    catch(e){
      if (addrOk(routerAddr)){
        router = new ethers.Contract(routerAddr, ROUTER_ABI, ro);
        if (!addrOk(factoryAddr)){ try{ factoryAddr = await router.factory(); }catch{} }
        if (addrOk(factoryAddr)){ factory = new ethers.Contract(factoryAddr, FACTORY_ABI, ro); setStatus('تم اعتماد إعداد الأدمن مباشرة.'); }
        else { throw e; }
      } else { throw e; }
    }

    // Attach pair
    let p = adminPair;
    if(!p){
      try{
        const def = await factory.getPair(CHAINS[chainId].wnative, CHAINS[chainId].USDT);
        if(addrOk(def) && def!='0x0000000000000000000000000000000000000000') p=def;
      }catch{}
    }
    if(!p) throw new Error('لم يتم إيجاد زوج صالح. عيّن الزوج من لوحة الأدمن.');
    await attachPair(p, ro);

    const sv = sessionStorage.getItem('swapMini.slippage') ?? localStorage.getItem('swapMini.slippage');
    if (!slDef && sv && els.slippage) els.slippage.value = sv;

    Promise.resolve(recalcQuote());
    if(pollT) clearInterval(pollT);
    pollT = setInterval(()=> updateReserves(false).catch(()=>{}), 10000);

    // Listen for admin live updates
    listenAdminUpdates((data)=>{
      try{
        if (data && data.pair && /^0x[a-fA-F0-9]{40}$/.test(data.pair)){
          setStatus('تحديث أدمن: إعادة تحميل الزوج…'); location.reload();
        }
      }catch{}
    });

    setAlert('');
  }

  async function boot(){ bind(); try{ await loadConfig(); setAlert('تم الجاهزية ✓'); }catch(e){ setAlert(e?.message || 'تعذّر الإقلاع','error'); } }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot, {once:true}); else boot();

  window.addEventListener('error', (e)=>{ dlog('window.onerror', String(e?.error?.message||e?.message||e)); });
  if (window.ethereum && window.ethereum.on) try{ window.ethereum.on('message', ()=>{}); }catch{}
  window.SwapMini = { connectWallet, doSwap, recalcQuote, debug: SwapMiniDebug };
})();