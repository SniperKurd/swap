<?php
// /swap-mini/upload-image.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$upDir = __DIR__ . '/uploads';
if (!is_dir($upDir)) {
  @mkdir($upDir, 0775, true);
}

if (!isset($_FILES['file'])) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'no file'], JSON_UNESCAPED_UNICODE);
  exit;
}

$f = $_FILES['file'];
if ($f['error'] !== UPLOAD_ERR_OK) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'upload error'], JSON_UNESCAPED_UNICODE);
  exit;
}

$max = 2 * 1024 * 1024; // 2MB
if ($f['size'] > $max) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'file too large (max 2MB)'], JSON_UNESCAPED_UNICODE);
  exit;
}

// تحقق نوع الملف
$allowed = [
  'image/png' => 'png',
  'image/jpeg'=> 'jpg',
  'image/jpg' => 'jpg',
  'image/svg+xml' => 'svg',
  'image/webp'=> 'webp',
  'image/gif' => 'gif'
];
$mime = mime_content_type($f['tmp_name']);
$ext  = $allowed[$mime] ?? null;
if (!$ext) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'unsupported type'], JSON_UNESCAPED_UNICODE);
  exit;
}

// اسم ملف آمن
$base = preg_replace('/[^a-zA-Z0-9_\-]/', '_', pathinfo($f['name'], PATHINFO_FILENAME));
$base = $base ?: 'icon';
$fname = $base . '_' . dechex(time()) . '_' . bin2hex(random_bytes(2)) . '.' . $ext;
$dest = $upDir . '/' . $fname;

if (!move_uploaded_file($f['tmp_name'], $dest)) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'move failed'], JSON_UNESCAPED_UNICODE);
  exit;
}

// ارجع الرابط النسبي ليستعمله الواجهة
$url = '/swap-mini/uploads/' . $fname;
echo json_encode(['ok'=>true,'url'=>$url], JSON_UNESCAPED_UNICODE);
