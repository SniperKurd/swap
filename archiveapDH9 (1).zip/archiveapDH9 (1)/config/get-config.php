<?php
// /swap-mini/config/get-config.php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$cfgFile = __DIR__ . '/config.json';

$defaults = [
  'chainId' => 56,
  'defaultSlippage' => '1',
  'networks' => [
    '56' => [
      'router'  => '0x10ED43C718714eb63d5aA57B78B54704E256024E',
      'factory' => '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
      'rpc'     => 'https://bsc-dataseed.binance.org'
    ],
    '97' => [
      'router'=>'0x9ac64cc6e4415144c455bd8e4837fea55603e5c3',
      'factory' => '0x6725F303b657a9451d8BA641348b6761A6CC7a17',
      'rpc'     => 'https://bsc-testnet.publicnode.com'
    ],
  ],
  'pairs' => [],
];

$cfg = $defaults;
if (is_file($cfgFile)) {
  $raw = file_get_contents($cfgFile);
  if ($raw !== false) {
    $j = json_decode($raw, true);
    if (is_array($j)) {
      $cfg['chainId'] = isset($j['chainId']) ? (int)$j['chainId'] : $cfg['chainId'];
      $cfg['defaultSlippage'] = isset($j['defaultSlippage']) ? (string)$j['defaultSlippage'] : $cfg['defaultSlippage'];
      if (isset($j['networks']) && is_array($j['networks'])) {
        foreach (['56','97'] as $k) {
          if (isset($j['networks'][$k]) && is_array($j['networks'][$k])) {
            $cfg['networks'][$k]['router']  = $j['networks'][$k]['router']  ?? $cfg['networks'][$k]['router'];
            $cfg['networks'][$k]['factory'] = $j['networks'][$k]['factory'] ?? $cfg['networks'][$k]['factory'];
            $cfg['networks'][$k]['rpc']     = $j['networks'][$k]['rpc']     ?? $cfg['networks'][$k]['rpc'];
          }
        }
      }
      if (isset($j['pairs']) && is_array($j['pairs'])) {
        $cfg['pairs'] = $j['pairs'];
      }
      if (isset($j['defaultPairId']) && is_string($j['defaultPairId'])) {
        $cfg['defaultPairId'] = $j['defaultPairId'];
      }
      if (isset($j['updatedAt'])) {
        $cfg['updatedAt'] = $j['updatedAt'];
      }
    }
  }
}

$cid = (int)($cfg['chainId'] ?? 56);
$net = $cfg['networks'][(string)$cid] ?? $cfg['networks']['56'];
$cfg['router']  = $net['router'];
$cfg['factory'] = $net['factory'];

echo json_encode([
  'ok' => true,
  'chainId' => $cfg['chainId'],
  'defaultSlippage' => $cfg['defaultSlippage'],
  'networks' => $cfg['networks'],
  'router' => $cfg['router'],
  'factory' => $cfg['factory'],
  'pairs' => $cfg['pairs'],
  'defaultPairId' => $cfg['defaultPairId'] ?? null,
  'updatedAt' => $cfg['updatedAt'] ?? gmdate('c'),
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
