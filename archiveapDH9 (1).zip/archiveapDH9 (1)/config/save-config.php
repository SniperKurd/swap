<?php
// /swap-mini/config/save-config.php (no token; with sanitize + rpc support)
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

$cfgDir  = __DIR__;
$cfgFile = $cfgDir . '/config.json';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'invalid json body'], JSON_UNESCAPED_UNICODE);
  exit;
}

// أدوات
function clean_invis($v){
  if (!is_string($v)) return '';
  return trim(preg_replace('/[\x{200C}\x{200D}\x{200E}\x{200F}\x{202A}-\x{202E}\x{2066}-\x{2069}\x{00A0}]/u','', $v));
}
function clean_addr($v){ return preg_replace('/\s+/', '', clean_invis($v)); }
function addr_ok($v){ return is_string($v) && preg_match('/^0x[a-fA-F0-9]{40}$/', $v); }
function clean_rpc($v){ return preg_replace('/\s+/', '', clean_invis($v)); }
function rpc_ok($u){ return is_string($u) && preg_match('#^https://[A-Za-z0-9\.\-:_/]+$#', $u); }

$chainId = isset($data['chainId']) ? (int)$data['chainId'] : 56;
if (!in_array($chainId, [56,97], true)) $chainId = 56;

// شبكات
$defaults = [
  '56' => [
    'router'  => '0x10ED43C718714eb63d5aA57B78B54704E256024E',
    'factory' => '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',
    'rpc'     => 'https://bsc-dataseed.binance.org'
  ],
  '97' => [
    'router'=>'0x9ac64cc6e4415144c455bd8e4837fea55603e5c3',
    'factory' => '0x6725F303b657a9451d8BA641348b6761A6CC7a17',
    'rpc'     => 'https://bsc-testnet.publicnode.com'
  ]
];

$networks = isset($data['networks']) && is_array($data['networks']) ? $data['networks'] : [];
$outNetworks = [];
foreach (['56','97'] as $k){
  $r  = clean_addr($networks[$k]['router']  ?? $defaults[$k]['router']);
  $f  = clean_addr($networks[$k]['factory'] ?? $defaults[$k]['factory']);
  $rp = clean_rpc ($networks[$k]['rpc']     ?? $defaults[$k]['rpc']);
  if (!addr_ok($r) || !addr_ok($f)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>"invalid router/factory for chain $k"], JSON_UNESCAPED_UNICODE);
    exit;
  }
  if (!rpc_ok($rp)) { $rp = $defaults[$k]['rpc']; } // لا نُسقط الطلب لو RPC غير صالح، نعيد الافتراضي
  $outNetworks[$k] = ['router'=>$r, 'factory'=>$f, 'rpc'=>$rp];
}

// زوج واحد
$defaultPairId = isset($data['defaultPairId']) && is_string($data['defaultPairId']) ? $data['defaultPairId'] : null;

$pairs = [];
if (isset($data['pairs']) && is_array($data['pairs'])) {
  foreach ($data['pairs'] as $p){
    if (!is_array($p)) continue;
    $entry = [
      'id'     => isset($p['id']) && $p['id'] !== '' ? (string)$p['id'] : null,
      'name'   => isset($p['name']) && $p['name'] !== '' ? (string)$p['name'] : null,
      'chainId'=> isset($p['chainId']) ? (int)$p['chainId'] : $chainId,
      'pair'   => isset($p['pair']) && $p['pair'] !== '' ? clean_addr((string)$p['pair']) : null,
      'tokenA' => isset($p['tokenA']) && $p['tokenA'] !== '' ? clean_addr((string)$p['tokenA']) : null,
      'tokenB' => isset($p['tokenB']) && $p['tokenB'] !== '' ? clean_addr((string)$p['tokenB']) : null,
      'iconA'  => isset($p['iconA']) && $p['iconA'] !== '' ? (string)$p['iconA'] : null,
      'iconB'  => isset($p['iconB']) && $p['iconB'] !== '' ? (string)$p['iconB'] : null,
    ];
    if ($entry['pair'] !== null   && !addr_ok($entry['pair']))   $entry['pair']   = null;
    if ($entry['tokenA'] !== null && !addr_ok($entry['tokenA'])) $entry['tokenA'] = null;
    if ($entry['tokenB'] !== null && !addr_ok($entry['tokenB'])) $entry['tokenB'] = null;

    if ($entry['id'] === null && $entry['pair'] !== null) $entry['id'] = $entry['pair'];
    if ($entry['id'] === null) $entry['id'] = 'pair_'.dechex(time()).bin2hex(random_bytes(2));

    $pairs[] = $entry;
  }
}
if (count($pairs) > 1) { $pairs = [ $pairs[0] ]; }
if ($defaultPairId === null && !empty($pairs)) $defaultPairId = $pairs[0]['id'];

// ترتيب الافتراضي أولاً (احتياطيًا)
if ($defaultPairId !== null && count($pairs) > 1) {
  foreach ($pairs as $i=>$pp) {
    if (($pp['id'] ?? '') === $defaultPairId) {
      if ($i>0) { $x=$pairs[$i]; array_splice($pairs, $i, 1); array_unshift($pairs, $x); }
      break;
    }
  }
}

$out = [
  'chainId' => $chainId,
  'defaultSlippage' => isset($data['defaultSlippage']) ? (string)$data['defaultSlippage'] : '1',
  'networks' => $outNetworks,
  'defaultPairId' => $defaultPairId,
  'pairs' => $pairs,
  'updatedAt' => gmdate('c'),
];

if (!is_dir($cfgDir)) { @mkdir($cfgDir, 0775, true); }
$ok = @file_put_contents($cfgFile, json_encode($out, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT), LOCK_EX);
if ($ok === false) {
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'failed to write config.json'], JSON_UNESCAPED_UNICODE);
  exit;
}

echo json_encode(['ok'=>true,'saved'=>basename($cfgFile)], JSON_UNESCAPED_UNICODE);
